import React,{useState} from "react"
import { Card, } from 'react-bootstrap'
import { FaUserCircle, FaReplyAll } from 'react-icons/fa'

const Comment = (props) => {
    const [tweet,setTweet] = useState(JSON.parse(props.data))
    const [ReplyMessage, setComment] = useState("")
    const dateFormat = { year: 'numeric', month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' }
    const Replied_userId = sessionStorage.getItem('email')

    fetch("https://localhost:5001/Tweets/"+Replied_userId+"/get/"+tweet.tweetId, {
            method: 'GET',
            headers: {
                "Content-Type": 'application/JSON',
                "Accept": 'application/JSON',
                "Authorization": 'Bearer '+sessionStorage.getItem('token')
            }
        }).then(result=>result.json()).then(data=>setTweet(data))

    const postComment = async (e)=>{
        e.preventDefault()
        let cmtObject = {Replied_userId,ReplyMessage}
        await fetch("https://localhost:5001/Tweets/"+Replied_userId+"/reply/"+tweet.tweetId, {
            method: 'POST',
            body: JSON.stringify(cmtObject),
            headers: {
                "Content-Type": 'application/JSON',
                "Accept": 'application/JSON',
                "Authorization": 'Bearer '+sessionStorage.getItem('token')
            }
        }).then(setComment(""));
    }

    return (
        <div>
            <Card>
                <Card.Body>
                    <Card.Header><FaUserCircle size={25} /> {tweet.creatorId.split("@")[0]} <p style={{ float: 'right', fontSize: '10pt' }}>{(new Date(tweet.createTime)).toLocaleDateString('en-us', dateFormat)} </p></Card.Header>
                    <Card.Text>
                        {tweet.content}<br/><br/>
                        {tweet.tags}
                    </Card.Text><hr />
                    <p style={{ marginBottom: '20pt' }}><textarea rows="1" placeholder="Comment.." onChange={(e) => setComment(e.target.value)} value={ReplyMessage} ></textarea>
                        <button className="btn shadow-none" onClick={postComment}><FaReplyAll size={30} style={{ float: 'right' }} /></button>
                    </p>
                    {
                        tweet.replys.reverse().map(
                            (t) => (<React.Fragment key={t.replied_userId + t.reply_Time}>
                                <div style={{ marginBottom: "10pt" }}>
                                    <><FaUserCircle size={15} /> {t.replied_userId.split("@")[0]} <p style={{ float: 'right', fontSize: '7pt' }}>{(new Date(t.reply_Time)).toLocaleDateString('en-us', dateFormat)} </p></>
                                    <br />{t.replyMessage}
                                </div><hr />
                            </React.Fragment>))
                    }
                </Card.Body>
            </Card>
        </div>
    )
}

export default Comment