import './App.css'
import Login from './User/Login.js'
import Register from './User/Register.js'
import ResetPassword from './User/ResetPassword.js'
import Home from './User/Home.js'
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom'

function App() {

  const RequireAuth = () => {
    return (sessionStorage.getItem('token'))?<Home/>:<Navigate to="/login"/>
    
  }

  return (
    <div>
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Login />
          } />
          <Route path="/login" element={<Login />
          } />
          <Route path="/signup" element={<Register />
          } />
          <Route path="/reset-password" element={<ResetPassword />
          } />
          <Route path="/home" element={<RequireAuth></RequireAuth>}></Route>
        </Routes>
      </BrowserRouter>
    </div>
  );
}

export default App;
