import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import Header from './Header.js'
import swal from 'sweetalert'

const ResetPassword = () => {

    const [userName, setEmail] = useState("");
    const [contactNumber, setContact] = useState("");
    const [password, setPassword] = useState("");
    const [password1, setPassword1] = useState("");
    const navigate = useNavigate();

    const signup = async (e) => {
        e.preventDefault()
        if(password!==password1){
            swal("Oops..","Password not matching","warning")
            return
        }
        let signupModel = { userName, password, contactNumber };
        let checkMail = await fetch("https://localhost:5001/Tweets/search/" + userName);
        let result = await checkMail.json()
        if (result.email !== userName) {
            swal("Oops..", "Email not registered!", "error")
        }
        else {
            let result = await fetch("https://localhost:5001/Tweets/" + { userName } + "/forget-Password", {
                method: 'POST',
                body: JSON.stringify(signupModel),
                headers: {
                    "Content-Type": 'application/JSON',
                    "Accept": 'application/JSON'
                }
            });
            result = await result.json()
            if (result === "Password Successfully Changed") {
                setContact("");
                setEmail("");
                setPassword("");
                sessionStorage.removeItem("name")
                sessionStorage.removeItem("token")
                sessionStorage.removeItem("email")
                sessionStorage.removeItem("phone")
                swal("Success", "Password Updated! Login to proceed..", "success", {
                    button: false,
                    timer: 2000
                }).then(() => navigate('/login'))
            }
            else {
                swal("Oops..", result, "error")
            }
        }
    }

    return (
        <div>
            <Header />
            <form className="col-sm-4 offset-sm-4 userContainer" onSubmit={signup}>
                <h1>Reset Password</h1>
                <input type="email" onChange={(e) => setEmail(e.target.value)} value={userName} className="form-control" placeholder="Email" required={true} />
                <input type="text" onChange={(e) => setContact(e.target.value)} value={contactNumber} className="form-control" placeholder="Contact Number" required={true} />
                <input type="password" onChange={(e) => setPassword(e.target.value)} value={password} className="form-control" placeholder="New Password" required={true} />
                <input type="password" onChange={(e) => setPassword1(e.target.value)} value={password1} className="form-control" placeholder="Confirm New Password" required={true} />
                <button className="btn btn-warning" >Update</button>
            </form>
        </div>
    );
}

export default ResetPassword;