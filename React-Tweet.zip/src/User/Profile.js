import React from "react"

const Profile = (props) =>{
    return <h2>{props.profile}</h2>
}

export default Profile
