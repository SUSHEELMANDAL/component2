import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import Header from './Header.js'
import swal from 'sweetalert'

const Register = () => {

    const [firstName, setFname] = useState("");
    const [lastName, setLname] = useState("");
    const [email, setEmail] = useState("");
    const [contactNumber, setContact] = useState("");
    const [password, setPassword] = useState("");
    const [password1, setPassword1] = useState("");
    const navigate = useNavigate();

    const signup = async (e) => {
        e.preventDefault()
        if(password!==password1){
            swal("Oops..","Password not matching","warning")
            return
        }
        let signupModel = { firstName, lastName, email, password, contactNumber };
        let checkMail = await fetch("https://localhost:5001/Tweets/search/" + email);
        let result = await checkMail.json()
        if (result.email === email) {
            swal("Oops..","Email Already Registered","warning")
        }
        else {
            let result = await fetch("https://localhost:5001/Tweets/Register", {
                method: 'POST',
                body: JSON.stringify(signupModel),
                headers: {
                    "Content-Type": 'application/JSON',
                    "Accept": 'application/JSON'
                }
            });
            result = await result.json()
            console.info(result);
            setFname("");
            setLname("");
            setContact("");
            setEmail("");
            setPassword("");
            swal("Success","Registration Successful! Login to proceed..","success",{
                button:false,
                timer:2000
            }).then(()=>navigate('/login'))
            
        }
    }

    return (
        <div>
            <Header />
            <form className="col-sm-4 offset-sm-4 userContainer" onSubmit={signup}>
                <h1>Sign Up</h1>
                <input type="text" onChange={(e) => setFname(e.target.value)} value={firstName} className="form-control" placeholder="First Name" required={true}/>
                <input type="text" onChange={(e) => setLname(e.target.value)} value={lastName} className="form-control" placeholder="Last Name" required={true}/>
                <input type="email" onChange={(e) => setEmail(e.target.value)} value={email} className="form-control" placeholder="Email" required={true}/>
                <input type="tel" onChange={(e) => setContact(e.target.value)} value={contactNumber} className="form-control" placeholder="Contact Number" pattern="[0-9]{10}" required={true}/>
                <input type="password" onChange={(e) => setPassword(e.target.value)} value={password} className="form-control" placeholder="Password" required={true}/>
                <input type="password" onChange={(e) => setPassword1(e.target.value)} value={password1} className="form-control" placeholder="Confirm Password" required={true}/>
                <button className="btn btn-success" >Register</button>
            </form>
        </div>
    );
}

export default Register;