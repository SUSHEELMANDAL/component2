import React, {  useState } from 'react'
import Head from '../User/Header.js'
import PostTweet from '../Tweet/PostTweet.js'
import ViewUser from './Viewusers.js'
import ViewAllTweet from '../Tweet/ViewAllTweet.js'
import {ImUserTie} from 'react-icons/im'
import {AiOutlineMail, AiOutlinePhone} from 'react-icons/ai'
import {BsKey} from 'react-icons/bs'
import Comment from '../Tweet/Comment.js'
import {Link} from 'react-router-dom'
import Profile from './Profile.js'

const Home = () => {
    const [option, setOption] = useState("All")
    const [tweet,setTweet] = useState(null)
    const [user, setUser] = useState(null)
    console.info(option)
    let display = <ViewAllTweet name="All" comment={setOption} showtweet={setTweet}/>
    if(option==="All"){
        display = <ViewAllTweet name="All" comment={setOption} showtweet={setTweet}/>
    }
    else if(option==="Own"){
        display = <ViewAllTweet name="Own" comment={setOption} showtweet={setTweet}/>
    }
    else if(option==="Comment"){
        display=<Comment comment={setOption} data={JSON.stringify(tweet)}/>
    }
    else if(option==="Users"){
        display = <ViewUser comment={setOption} profile={setUser}/>
    }
    else{
        display=(sessionStorage.getItem('email')===JSON.parse(user).email)?(setOption("Own")):<ViewAllTweet name={JSON.parse(user).email} comment={setOption} showtweet={setTweet}/>
    }

    return (
        <div>
            <div className="row">
            <Head />
                <form className="col-sm-2"  style={{marginLeft:'40pt'}}>
                    <input type="radio" className="btn-check" name="options" id="option1" value="All" onChange={(e) => setOption(e.target.value)} checked={option==="All"}/>
                    <label className="btn btn-outline-dark shadow-none" htmlFor="option1">View All Tweets</label><br />

                    <input type="radio" className="btn-check" name="options" id="option2" value="Own" onChange={(e) => setOption(e.target.value)}  checked={option==="Own"}/>
                    <label className="btn btn-outline-dark shadow-none" htmlFor="option2">View Own Tweets</label><br />

                    <input type="radio" className="btn-check" name="options" id="option3" value="Users" onChange={(e) => setOption(e.target.value)} checked={option==="Users"}/>
                    <label className="btn btn-outline-dark shadow-none" htmlFor="option3">View All Users</label><br />

                </form>
                <div className="col-sm-6">
                    <PostTweet />
                    
                    {display}
                </div>
                <div className="col-sm-1"></div>
                { <div className="col-sm-2 text-black">
                    <ImUserTie size={30}/>  {sessionStorage.getItem("name")}<br/>
                    <AiOutlineMail/> {sessionStorage.getItem("email")}<br/>
                    <AiOutlinePhone/> {sessionStorage.getItem("phone")}<br/>
                    <BsKey/> <Link to="/reset-password" style={{textDecoration:'none'}}>Change Password</Link>
                </div> }

            </div>
        </div>
    );
}
export default Home;