import React, { useState } from "react"
import { Card } from 'react-bootstrap'
import {AiOutlineMail, AiOutlinePhone} from 'react-icons/ai'
import { FaUserCircle } from 'react-icons/fa'

const ViewUser = (props) => {
    const [users, setUsers] = useState([])
    let url = "https://localhost:5001/Tweets/Users/All"

    fetch(url, {
        method: 'GET',
        headers: {
            Accept: "application/json, text/plain, */*",
            Authorization: 'Bearer ' + sessionStorage.getItem("token")
        }
    }).then(result => result.json()).then(data => setUsers(data))

    const userProfile = (profile) =>{
        props.comment("viewProfile")
        props.profile(profile)
    }

    return (<div>
        <hr style={{backgroundColor:'black'}}/>
        <h4 className="text-black">Tweet Family..</h4><br/>
        {
            users.map(
                (u) => (<React.Fragment key={u.email}>
                    <Card style={{ marginBottom: "10pt" }}>
                        <Card.Body>
                            <Card.Title className="btn"  onClick={()=>userProfile(JSON.stringify(u))}><FaUserCircle size={25}/> {u.firstName}</Card.Title>
                            <Card.Text>
                                <AiOutlineMail/>{u.email}
                                <AiOutlinePhone style={{marginLeft:'20pt'}}/>{u.contactNumber}
                            </Card.Text>
                        </Card.Body>
                    </Card>
                </React.Fragment>)
            )
        }
    </div>)
}

export default ViewUser
