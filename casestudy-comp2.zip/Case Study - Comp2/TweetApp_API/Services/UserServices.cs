﻿using AutoMapper;
using MongoDB.Bson;
using MongoDB.Driver;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Tweet_App_API.DataBaseLayer;
using Tweet_App_API.JWTAuthentication;
using Tweet_App_API.Model;

namespace Tweet_App_API.Services
{
    public class UserServices : IUserServices
    {
        private readonly IMongoCollection<User> _users;
        private readonly IMapper _mapper;
        private readonly IAuthService _auth;

        public UserServices(IDBClient client, IMapper mapper, IAuthService authService)
        {
            _users = client.GetUserCollection();
            _mapper = mapper;
            _auth = authService;
        }

        private async Task<UserViewModel> GetUserByConatctAndEmail(string email, string conatctNumber)
        {
            var user = await _users.FindAsync<User>(emp => emp.Email.Equals(email) && emp.ContactNumber.Equals(conatctNumber));

            var result = await user?.FirstOrDefaultAsync();

            UserViewModel userViewModel = _mapper.Map<UserViewModel>(result);

            return userViewModel;
        }

        public async Task<List<UserViewModel>> GetAllUsers()
        {

            var users = await _users.FindAsync(usr => true);
            var result = users?.ToList();

            var userViewModel = _mapper.Map<List<UserViewModel>>(result);

            return userViewModel;
        }

        public async Task<UserViewModel> GetUserByEmail(string email)
        {
            var user = await _users.FindAsync<User>(emp => emp.Email.Equals(email));

            var result = await user.FirstOrDefaultAsync();

            UserViewModel userViewModel = _mapper.Map<UserViewModel>(result);

            if(userViewModel is null)
            {
                return (new UserViewModel());
            }

            return userViewModel;
        }


        public async Task<UserResponse> Register(User usr)
        {
            usr.LoginId = usr.FirstName + Guid.NewGuid().ToString();
            var responsse = new UserResponse() { Email = usr.Email, LoginId = usr.LoginId, Errors = new List<string>() };
            

            try
            {
                //Hash the password before storing
                usr.Password = CryptoGraphy.GetHash(usr.Password);
                await _users.InsertOneAsync(usr);
            }
            catch (Exception ex)
            {
                if (ex.Message.Contains("customLoginId"))
                {
                    responsse.Errors.Add("Login ID is already exisit");
                }

                if (ex.Message.Contains("customEmail"))
                {
                    responsse.Errors.Add("Email is already exisit");
                    responsse.LoginId = null;
                }

            }
            
            return responsse;
        }

        public async Task<UserResponse> LoginUser(string email, string password)
        {
            var user = await _users.FindAsync<User>(emp => emp.Email == email).Result.FirstOrDefaultAsync();

            var userResponse = new UserResponse() { Errors = new List<string>() };

            if (user == null)
            {
                userResponse.Errors.Add("Invalid Email ID");
                return userResponse;
            }

            userResponse.Email = user.Email;
            userResponse.LoginId = user.FirstName;
            userResponse.RefreshToken = user.ContactNumber;

            //Create hash value of entered password
            var newHashValue = CryptoGraphy.GetHash(password);


            //Check the hash value of entered password and hash password stored in the DB
            if (CryptoGraphy.CompareHash(newHashValue, user.Password))
            {
                userResponse.Token = _auth.GenerateToken(email);
                return userResponse;
            }

            userResponse.LoginId = null;
            userResponse.Errors.Add("Incorrect Password");
            return userResponse;
        }

        public async Task<bool> ResetPassword(string email, string newPassword, string contactNumber)
        {
            var user = await GetUserByConatctAndEmail(email, contactNumber);
            if (user != null)
            {
                var hashPassword = CryptoGraphy.GetHash(newPassword);
                var filter = new BsonDocument("email", email);
                var update = Builders<User>.Update.Set("password", hashPassword);
                await _users.FindOneAndUpdateAsync(filter, update);
                return true;
            }

            return false;
        }
    }
}

