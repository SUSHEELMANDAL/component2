import React, { useState } from 'react'
import { useNavigate, Link } from 'react-router-dom'
import Header from './Header.js'
import swal from 'sweetalert'
import {AiOutlineMail} from 'react-icons/ai'
import {BsKey} from 'react-icons/bs'

const Login = () => {
    const [userName, setEmail] = useState("");
    const [password, setPassword] = useState("");
    const navigate = useNavigate();

    const signup = async (e) => {
        e.preventDefault()
        let signupModel = { userName, password };
        let result = await fetch("https://localhost:5001/Tweets/Login", {
            method: 'POST',
            body: JSON.stringify(signupModel),
            headers: {
                "Content-Type": 'application/JSON',
                "Accept": 'application/JSON'
            }
        });
        result = await result.json()
        if (result.token != null) {
            setEmail("");
            setPassword("");
            sessionStorage.setItem("email", result.email)
            sessionStorage.setItem("name", result.loginId)
            sessionStorage.setItem("token", result.token)
            sessionStorage.setItem("phone", result.refreshToken)
            swal("Login Successful!", " ", "success", {
                button: false,
                timer: 2000
            }).then(() => navigate('/home'))
            //navigate('/home');
        }
        else {
            swal("Failed", JSON.stringify(result.errors), "error")
        }

    }

    return (

        <div>
            <Header />
                <form className="col-sm-4 offset-sm-4 userContainer" onSubmit={signup}>
                    <h1>Login</h1>
                    <input type="email" onChange={(e) => setEmail(e.target.value)} value={userName} className="form-control" placeholder="Email" required={true}/>
                    <input type="password" onChange={(e) => setPassword(e.target.value)} value={password} className="form-control" placeholder="Password" required={true} />
                    <Link to="/reset-password" className="forgotPassword" replace>Forgot Password</Link>
                    <br/><button type="submit" className="btn btn-success">Login</button>
                </form>
        </div>
    );
}

export default Login;