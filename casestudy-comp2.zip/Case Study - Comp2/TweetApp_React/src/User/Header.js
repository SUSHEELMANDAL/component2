import React from "react";
import { Navbar, Nav, Container } from "react-bootstrap";
//import {Twitter} from 'react-bootstrap-icons'
import {useNavigate, Link} from 'react-router-dom';
import swal from 'sweetalert'
import {GrTwitter} from 'react-icons/gr'
import {BiLogIn,BiLogOut,BiUser} from 'react-icons/bi'


const Header = () => {
    const navigate = useNavigate();
    const logout = () =>{
        console.info("logout")
        sessionStorage.removeItem("name")
        sessionStorage.removeItem("token")
        sessionStorage.removeItem("email")
        sessionStorage.removeItem("phone")
        swal("Logged Out Successfully!"," ","info",{
            button:false,
            timer:2000
        }).then(() => navigate('/login'))
    }
    return (
        <Navbar bg="primary" variant="dark">
            <Container>
            <Navbar.Brand><h1><GrTwitter/>Twitter</h1></Navbar.Brand>
                <Nav className="navbar_wrapper">
                    {
                        sessionStorage.getItem('token')?
                        <>
                        <Link to="/login" onClick={logout}><BiLogOut size={25}/>Logout</Link>
                        </>:<>
                        <Link to="/login"><BiLogIn size={25}/>Login</Link>
                        <Link to="/signup"><BiUser size={25}/>Sign Up</Link>
                        </>
                    }
                    
                </Nav>
            </Container>
        </Navbar>
    );
}

export default React.memo(Header)
