import React, { useState } from "react"
import { Card, } from 'react-bootstrap'
import swal from 'sweetalert'
import { AiOutlineLike } from 'react-icons/ai'
import { GoCommentDiscussion } from 'react-icons/go'
import { FaUserCircle } from 'react-icons/fa'

const ViewAllTweet = (props) => {
    const dateFormat = { year: 'numeric', month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' }

    var [tweets, setTweets] = useState([])

    let url = "https://localhost:5001/Tweets/"
    if (props.name === "All") {
        url = url + "All"
    }
    else if (props.name === "Own") {
        url = url + sessionStorage.getItem('email')
    }
    else {
        url = url + props.name
    }

    fetch(url, {
        method: 'GET',
        headers: {
            Accept: "application/json, text/plain, */*",
            Authorization: 'Bearer ' + sessionStorage.getItem("token")
        }
    }).then(result => result.json()).then(data => setTweets(data))



    var likeTweet = (id) => {
        fetch("https://localhost:5001/Tweets/" + sessionStorage.getItem('email') + "/Like/" + id, {
            method: 'PUT',
            headers: {
                Accept: "application/json, text/plain, */*",
                Authorization: 'Bearer ' + sessionStorage.getItem("token")
            }
        })
    }

    var deleteTweet = (id) => {

        swal({
            title: "Are you sure?",
            buttons: true,
            dangerMode: true,
            className: "swalCSS"
        })
            .then((willDelete) => {
                if (willDelete) {
                    fetch("https://localhost:5001/Tweets/" + sessionStorage.getItem('email') + "/delete/" + id, {
                        method: 'DELETE',
                        headers: {
                            Accept: "application/json, text/plain, */*",
                            Authorization: 'Bearer ' + sessionStorage.getItem("token")
                        }
                    })
                } else {

                }
            });


    }
    return (<div>
        <hr style={{backgroundColor:'white'}}/>
        <h4 className="text-white">{
            (props.name==="All")?<p>Latest Tweets..</p>:
            (props.name==="Own")?<p>Your Tweets</p>:
            <p>Tweets from {props.name}</p>}
        </h4>
        {
            tweets.reverse().map(
                (t) => (<React.Fragment key={t.tweetId}>
                    <Card style={{ marginBottom: "10pt" }}>
                        <Card.Body>
                            <Card.Header><FaUserCircle size={25} /> {t.creatorId.split("@")[0]} <p style={{ float: 'right', fontSize: '8pt' }}>{(new Date(t.createTime)).toLocaleDateString('en-us', dateFormat)} </p></Card.Header>
                            <Card.Text>
                                {t.content}<br /><br />
                                {t.tags}
                            </Card.Text>
                            {
                                (props.name === "Own") ? <button className="btn btn-danger btn-sm shadow-none" onClick={() => deleteTweet(t.tweetId)}>Delete</button>
                                    :
                                    <div style={{ textAlign: 'right' }}><button className="btn btn-sm shadow-none" onClick={() => { likeTweet(t.tweetId) }} style={{ float: 'left' }}><AiOutlineLike size={25} />{t.likes.length}</button>
                                        <button className="btn shadow-none" onClick={() => { props.comment("Comment"); props.showtweet(t); }}>
                                            <GoCommentDiscussion size={25} />
                                        </button>
                                    </div>
                            }
                        </Card.Body>
                    </Card>
                </React.Fragment>)
            )
        }
    </div>)
}

export default ViewAllTweet
