import React,{useState} from 'react'
import swal from 'sweetalert'

const PostTweet = () => {


    const [content,setTweet] = useState("")
    const [tags,setTags] = useState("")
    const creatorId = sessionStorage.getItem("email")
    const token = sessionStorage.getItem("token")

    const post = async (e) => {
        e.preventDefault()
        let tweetObject = {creatorId,content,tags}
        let response = await fetch("https://localhost:5001/Tweets/"+creatorId+"/Add", {
            method: 'POST',
            body: JSON.stringify(tweetObject),
            headers: {
                "Content-Type": 'application/JSON',
                "Accept": 'application/JSON',
                "Authorization": 'Bearer '+token
            }
        })
        let result = await response.json()
        response = await response.status
        if(response===200){
            swal("","","success",{button:false,timer:2000})
            setTweet("")
            setTags("")
        }
        else{
            swal("Oops..","Error due to one of the following:\n*Tweet length is more than 144char\n*Tag length is more than 50 char","warning")
        }
    }

    
    return (
        <form onSubmit={post} style={{marginBottom:"40pt"}}>
            <textarea rows="3"  placeholder="What's happening?..." value={content} onChange={(e)=>setTweet(e.target.value)} required/>
            <input type="text"  placeholder="#Tags" value={tags} onChange={(e)=>setTags(e.target.value)}/>
            <button className="btn btn-primary shadow-none" style={{float:"right"}} >Tweet</button>
        </form>
    )
}

export default React.memo(PostTweet)
